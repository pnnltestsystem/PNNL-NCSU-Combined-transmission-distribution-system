% Created by Xiangqi Zhu on 08/31/2016
% To create csv file for each load bus 

clear;clc; close all;


% --------------------------Get the solar shape ready---------------------
load('Solar_July11.mat')
PV=Solar_July11(:,3)';
PV=PV./(max(PV));% Normalize the solar profile

%-----------------------------Read in the load names----------------------
filename='IEEE123.xlsx';
sheet='Sheet1';
range='C1:C91';
[num1,txt1,raw1]=xlsread(filename, sheet,range,'txt');

% ----------------------Read in the phase information---------------------
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='F1:F91';
[num2,txt2,raw2]=xlsread(filename, sheet,range);

%----------------Get the solar peak at each bus ready-------------------
load('Profiles2.mat')
N=91; % Load bus number
Load=Profiles(1:N,:);
Peak=max(Load,[],2);
% N=numel(txt);
r=1;
PVPeak=r*Peak;

%------------------Create the PV profiles for each csv file--------------
PVprofiles=zeros(N,1440);

for i=1:N
    PeakPV=PVPeak(i);
    Profile=PeakPV*PV;
    PBase=Profile;
    t_base=0:1/12:(24-1/12);
    tq=0:1/60:(24-1/60);
    PVprofiles(i,:)=interp1(t_base,PBase,tq,'PCHIP');
end

PVmax=max(PVprofiles,[],2);
Totalmax=sum(PVmax);

save('PVprofiles','PVprofiles')
%    
%Create the csv files
for j=1:N
    Data=PVprofiles(j,:);
    filename=['PVShape' txt1{j} '.csv'];
    csvwrite(filename, Data');
end




