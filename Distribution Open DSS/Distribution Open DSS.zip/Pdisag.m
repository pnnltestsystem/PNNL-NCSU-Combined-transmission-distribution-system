function [PresLoad , NextLoad , NextLoad_Q , PresPV]=Pdisag(PresLoad, NextLoad, NextLoad_Q, PresPV ,Node,DeltP,N)
PriceInfo;
PF=0.8;
% N=91;
if DeltP>0  % Load increase
    % two ways to do load increase:
    %1. Load shifting 
    %2. PV curtailment 
    DRP=0; % initial real power value of demand response 
    if p_PVcurtl<=p_LoadShift  % Do PV curtailment first
        ratio=0.5; % curtail ratio
        if max(PresPV)~=0 % there is PV available 
            DRPV=zeros(1,N);
            for i=N:-1:1 % Choose the node with highest voltage
                DRPV(Node(i))=PresPV(Node(i))*ratio;
                DRP=DRP+PresPV(Node(i))*ratio; % PV curtailed
                PresPV(Node(i))=PresPV(Node(i))*(1-ratio); % PV remaining 
                if DRP>=DeltP
                    break;
                end
                    
            end
            
            if DRP<DeltP  % Do second round PV curtailment 
                for i=N:-1:1 % Choose the node with highest voltage
                DRP=DRP+PresPV(Node(i))*ratio; % PV curtailed
                PresPV(Node(i))=PresPV(Node(i))*(1-ratio); % PV remaining 
                if DRP>=DeltP
                    break;
                end
                    
                end
            end
            
        end
        
        if DRP<DeltP % Then do load shifting 
            load('HouseN.mat') % Get the number of houses at each bus  
            DRHouse=zeros(1,numel(HouseN));
            for i=N:-1:1 % Choose the node with highest voltage
                HouseNb=HouseN(Node(i));
                DRHouse(Node(i))=ceil(rand(1)*HouseNb); % How many house could do demand response 
                DRP=DRP+DRHouse(Node(i))*3;
                PresLoad(Node(i))=PresLoad(Node(i))+DRHouse(Node(i))*3;
                NextLoad(Node(i))=NextLoad(Node(i))+DRHouse(Node(i))*3; % If AC is turned on, the minimum one time is 10 mins
                NextLoad_Q(Node(i))=NextLoad_Q(Node(i))+DRHouse(Node(i))*3/PF*sqrt(1-PF^2);
                if DRP>=DeltP
                    break;
                end    
            end
        end
    end
   
end

% [a,b]=sortrows(DRHouse')

%% 
if DeltP<0  % Load decrease
    % one way to do load decrease:
    %1. Load shifting 
    DRP=0; % initial real power value of demand response
    load('HouseN.mat') % Get the number of houses at each bus
    DRHouse=zeros(1,numel(HouseN));
    for i=1:N % Choose the node with lowest voltage 
        HouseNb=HouseN(Node(i));
        DRHouse(Node(i))=ceil(rand(1)*HouseNb); % How many house could do demand response
        DRP=DRP+DRHouse(Node(i))*3;
        PresLoad(Node(i))=PresLoad(Node(i))-DRHouse(Node(i))*3;
        NextLoad(Node(i))=NextLoad(Node(i))-DRHouse(Node(i))*3; % If AC is turned off, the minimum  time is 10 mins
        NextLoad_Q(Node(i))=NextLoad_Q(Node(i))-DRHouse(Node(i))*3/PF*sqrt(1-PF^2);
        if DRP>=abs(DeltP)
            break;
        end
    end
end

if DeltP==0
    
end

% PresLoad_Q=PresLoad/2;
% NextLoad_Q=NextLoad/2;
