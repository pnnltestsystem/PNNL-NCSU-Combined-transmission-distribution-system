% Created by Xiangqi Zhu on May 31, 2017
% To check if the results are right


clear;clc;close all
ratio=0.3489;

filename='input_update1.xlsx';
sheet='P';
range='BP2:BP289';
TransLoad=xlsread(filename,sheet,range);
TransLoad=TransLoad'*1000*ratio;


sheet1='pv';
range1='AV2:AV289';
TransPV=xlsread(filename,sheet1,range1);
TransPV=TransPV'*1000*ratio;

sheet2='Q';
range2='BP2:BP289';
TransLoadQ=xlsread(filename,sheet2,range2);
TransLoadQ=TransLoadQ'*1000*ratio;



TransNetload=TransLoad-TransPV;






