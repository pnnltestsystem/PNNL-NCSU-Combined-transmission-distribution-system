% Created by Xiangqi Zhu on Jun 21, 2017
% To implement the Q generation of PV
% Edited by Xiangqi Zhu on Jun 22, 2017, to convert this to a function 


function PVQGenerate(PVQbus, PV,TimeStep)

N=91;

PVcapa=max(PV,[],2); % Get the maximum PV output 
S=PVcapa; % Set the initial PV capacity as the maximum PV output 

QPVcapa=PVQbus; % Set the Q capacity as current Q output requirement 

for i=1:N
    if QPVcapa(i)~=0
        S(i)=sqrt(PVQbus(i)^2+PV(i,TimeStep)^2);
    end
end

%Read in the load name information
filename='IEEE123.xlsx';
sheet='Sheet1';
range='C1:C91';
[num,txt,raw]=xlsread(filename, sheet,range,'txt');

% Read in the load bus name  
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='D1:D91';
[num1,txt1,raw1]=xlsread(filename, sheet,range,'txt');

% Read in the peak real load
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='L1:L91';
VoltageLevel=xlsread(filename, sheet,range);

% Read in the phase 
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='F1:F91';
[num3,txt3,raw3]=xlsread(filename, sheet,range);

% Process the raw1 to make it all strings
N=numel(raw1);
for i=1:N
    tf = isnumeric(raw1{i});
    if tf==1
        raw1{i}=num2str(raw1{i});
    end
end
        
%------------------Write the loadshape information ------------------

N=numel(txt); % number of load
fileID = fopen('IEEE123_PVallloadswQ.dss','wt');
for i=1:N
    PVshape=['New LoadShape.PVShape' txt{i} '  npts=288  minterval=[5] pmult=(File=PVShape' txt{i} '.csv ) qmult=(File=PVShape' txt{i} 'Q.csv ) Action=Normalize'  '   \n'];
    fprintf(fileID,PVshape);
    PVsystem=['New PVSystem.PV' txt{i} '  phases=' num2str(num3(i))  '  bus1=' raw1{i}  ' KV=' num2str(VoltageLevel(i)) '   KVA=' num2str(S(i)) '  kvar=' num2str(QPVcapa(i)) '  pmpp=' num2str(PVcapa(i)) '  duty=PVShape' txt{i}   '   %%cutout='  num2str(0)     '   \n'];
    fprintf(fileID,PVsystem);
end

fclose(fileID);







