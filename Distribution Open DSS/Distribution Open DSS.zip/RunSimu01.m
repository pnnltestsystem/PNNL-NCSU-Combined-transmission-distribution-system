% Created by Xiangqi Zhu on Sep 29, 2016
% Run the case without the three regulatorss



function Vrms=RunSimu01
clear;clc;

%-------------------Read in the load bus information--------------------

filename='IEEE123.xlsx';
sheet='Sheet1';
range='C1:C91';
[num,txt,raw]=xlsread(filename, sheet,range,'txt');
n=numel(txt);
Vrms=zeros(n,1440);
load('IndexNew.mat')

%--------------------Run OpenDSS----------------------------------------

[DSSStartOK, DSSObj, DSSText] = DSSStartup;
if DSSStartOK
    % edit this to match your actual example file location
    DSSText.command='Compile (C:\Users\xzhu9\Documents\XZ\research\SunLampProject\DistributionTestSystem\OpenDSSSimu\123Bus\Run_IEEE123Bus01_woPVworegulator.dss)';

    DSSCircuit=DSSObj.ActiveCircuit;
    DSSSolution=DSSCircuit.Solution;
   
   % DSSSolution.Solve;
    MyYMatrix = DSSCircuit.SystemY;
    DSSMon=DSSCircuit.Monitors;
    
    % Get the data of all monitors 
    
    for i=1:n
        
        DSSMon.name=['v' txt{i}] ;
        Vrms(i,:) = ExtractMonitorData(DSSMon,1,2401.8);
    end
    t = ExtractMonitorData(DSSMon,0, 3600);
    
else
    a='DSS Did Not Start';
    disp(a)
end












