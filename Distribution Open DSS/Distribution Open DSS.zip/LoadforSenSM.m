% Created by Xiangqi Zhu on Aug 6, 2017
% Prepare the load for VLSM

clear;clc;close all;

tic


%% Load PV profiles and load profiles at initial condition
N=91; % Load bus number
T=288; % data points in a day 

% load('PV_oneyear_5min.mat')
% load('Load_oneyear_5min.mat')

% load('NewLoadPVData_Day1.mat')
% load('NewLoadQ.mat')

load('LoadPVData_oneyear07102017.mat')
load('LoadQData_oneyear07112017.mat')

load('SenSMmeanwoNormwoReg1.mat')
VLSM_P=SenSM;
load('QSenSM20woNormwoReg1.mat')
VLSM_Q=SenSM;


OneDayDataNo=288;
day=1;

PV=PVoneyear_new_Node(:,((day-1)*OneDayDataNo+1):(OneDayDataNo*day+1)); % PV real power
Load=Load_oneyear_new(:,((day-1)*OneDayDataNo+1):(OneDayDataNo*day+1)); % load real power
Load_Q=Load_Q_oneyear_new(:,((day-1)*OneDayDataNo+1):(OneDayDataNo*day+1)); % load reactive power

save('LoadforSenSM','Load','Load_Q')