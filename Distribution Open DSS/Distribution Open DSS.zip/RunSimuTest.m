% Created by Xiangqi Zhu on Sep 29, 2016
% Run the case without the three regulatorss

% Created by Xiangqi Zhu on Jun 21, 2017
% To 


% Vrms is the voltage at each node
% LoadSub is the total load at substation
% clear;clc;

%-------------------Read in the load bus information--------------------
clear;clc;close all;
filename='IEEE123.xlsx';
sheet='Sheet1';
range='C1:C91';
[num,txt,raw]=xlsread(filename, sheet,range,'txt');
n=numel(txt);
TimeStep=120;
Vrms=zeros(n,TimeStep);
load('IndexNew.mat')

%--------------------Run OpenDSS----------------------------------------

[DSSStartOK, DSSObj, DSSText] = DSSStartup;
if DSSStartOK
    % edit this to match your actual example file location
%     DSSText.command='clear';
%     DSSText.command=['New object=circuit.ieee123 basekv=4.16 Bus1=150 pu=' num2str(Vsub) ' R1=0 X1=0.0001 R0=0 X0=0.0001'];
    DSSText.command='Compile (C:\Users\zhux554.PNL\Documents\XZ\Research\SunLamp\Code\DistributionSys\OpenDSSSimu\123Bus\Run_IEEE123Bus01_wPVworegulator - Test.dss)';

    DSSText.command=['set mode=duty loadmult=1 stepsize=5m number=' num2str(TimeStep)];
    DSSText.command='solve';
%     DSSText.command='EXport powers';
%     DSSText.command='Export losses';
%     DSSText.command='Export Summary';
%     DSSText.command='Export Meters';

    
    DSSCircuit=DSSObj.ActiveCircuit;
    DSSSolution=DSSCircuit.Solution;
   
%    DSSSolution.Solve;
    MyYMatrix = DSSCircuit.SystemY;
    DSSMon=DSSCircuit.Monitors;
    
    % Get the data of all monitors 

    for i=1:n
        
            DSSMon.name=['v' txt{i}] ;
            Vrms(i,:) = ExtractMonitorData(DSSMon,1,2401.8);
            t = ExtractMonitorData(DSSMon,0, 3600);
        
    end
    
    DSSMon.name='s';
    P = ExtractMonitorData(DSSMon,1,1.0);
    Q = ExtractMonitorData(DSSMon,2,1.0);
    
    
    
else
    a='DSS Did Not Start';
    disp(a)
end












