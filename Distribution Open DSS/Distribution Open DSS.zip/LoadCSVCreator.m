% Created by Xiangqi Zhu on 08/31/2016
% To create csv file for each load bus 


function LoadCSVCreator(Load)
% Get the load name ready 
load('LoadName.mat')

BusN=numel(txt);

%Create the csv files
for j=1:BusN
   
    Data=Load(j,:);    
    filename=['Load' txt{j} '.csv'];
    %xlswrite(filename, Data');
	csvwrite(filename, Data');
end




