% Created by Xiangqi Zhu on Nov 30, 2016
% To fulfill the demand response from subtranmission level,
% and also do the local voltage profile check and do local demand response

% Currently, no regulators are used in this circuit, and 
% Edited by Xiangqi zhu on Dec 9, 2016

% Edited by Xiangqi Zhu on Aug 5, 2017

function [Load,V1,V0]=DistributionSys_v3(PV,Load,Load_Q,Vsub,P_DR_Load,Q_DR_PV,P_DR_PV,TimeStep,TimeStep_run,T_Total)

disp('-----------entering matlab function DistributionSys_v3 --------------------');

% DeltQ is not in use here
% PV_Constraint_Q is the range of the Q which smart inverter could produce 

%% Load PV profiles and load profiles
N=91; % Load bus number
S=max(PV,[],2)*11/9;% Capacity of PV at each bus 

%% Run original simulation
disp('-----------matlab function DistributionSys_v3, original simulation,  NewloadDSSCreatorPQ--------------------');
NewloadDSSCreatorPQ(Load,Load_Q); 

disp('-----------matlab function DistributionSys_v3, original simulation,  LoadCSVCreator--------------------');
LoadCSVCreator(Load);

disp('-----------matlab function DistributionSys_v3, original simulation,  LoadCSVCreatorQ--------------------');
LoadCSVCreatorQ(Load_Q,TimeStep);

disp('-----------matlab function DistributionSys_v3, original simulation,  NewDSSCreatorPV--------------------');
NewDSSCreatorPV(PV,TimeStep,T_Total);

disp('-----------matlab function DistributionSys_v3, original simulation,  PVCSVCreator_P--------------------');
PVCSVCreator_P(PV);

disp('-----------matlab function DistributionSys_v3, entering RunSimu2--------------------');
[P,Q,V0]=RunSimu2(Vsub,TimeStep_run);
disp('-----------matlab function DistributionSys_v3, leaving RunSimu2--------------------');



% Implement controllable load response
Load(:,TimeStep)=Load(:,TimeStep)+P_DR_Load';

% Implement PV curtailment
PV(:,TimeStep)=PV(:,TimeStep)+P_DR_PV';

%% Generate Q from smart inverters of PV panels
PVQGenerate(Q_DR_PV', PV,TimeStep)

disp('-----------matlab function DistributionSys_v3, control implementation finished-------------------');

% Create the new csv files for load and PV
disp('-----------matlab function DistributionSys_v3, DR simulation,  NewloadDSSCreatorPQ--------------------');
NewloadDSSCreatorPQ(Load,Load_Q); 

disp('-----------matlab function DistributionSys_v3, DR simulation,  LoadCSVCreator--------------------');
LoadCSVCreator(Load);

disp('-----------matlab function DistributionSys_v3, DR simulation,  PVCSVCreator_P--------------------');
PVCSVCreator_P(PV);

disp('-----------matlab function DistributionSys_v3, new csv files finished-------------------');

% [Load_Q]=LoadCSVCreatorQ(Load_Q,TimeStep);


disp('-----------matlab function DistributionSys_v3, entering RunSimu2 for DR--------------------');

[P,Q,V1]=RunSimu2(Vsub,TimeStep_run);

disp('-----------matlab function DistributionSys_v3, leaving RunSimu2 for DR--------------------');

%% Generate new constraints
% DR_Constraint_P=[sum(Load(:,TimeStep+1))*0.08,-sum(Load(:,TimeStep+1))*0.08];
% % DR_Constraint_Q=[sum(Load_Q(:,TimeStep+1))*0.08,-sum(Load_Q(:,TimeStep+1))*0.08];
% PV_Constraint_P=sum(PV(:,TimeStep+1))*0.3;




% for i=1:91
%     
%     [dummy, PV_Q(i)]=SmartInverter((PV(i,TimeStep)),S(i));
% end
% PV_Constraint_Q=sum(PV_Q)*0.3;














        
        
   
            
    
    
    
    
    
        
    
    
    
    
    







            
            
            
            
            
    
                
            
                
                
                
                
            
            
        
        
        
        
        
        
        
        
        
        
        
        
    



















