% Example of using Matlab to plot binary monitor data


clear;clc; close all;
[DSSStartOK, DSSObj, DSSText] = DSSStartup;

if DSSStartOK
    % edit this to match your actual example file location
    DSSText.command='Compile (C:\Users\xzhu9\Documents\XZ\research\SunLampProject\DistributionTestSystem\OpenDSSSimu\123Bus\Run_IEEE123Bus01.dss)';

    DSSCircuit=DSSObj.ActiveCircuit;
    DSSSolution=DSSCircuit.Solution;
   
   % DSSSolution.Solve;

    DSSMon=DSSCircuit.Monitors;
    DSSMon.name='s';
    Vrms = ExtractMonitorData(DSSMon,1,2401.8);
    t = ExtractMonitorData(DSSMon,0, 3600);
%     
%     DSSMon.name='s';
%     P = ExtractMonitorData(DSSMon,1,1.0);
%     Q = ExtractMonitorData(DSSMon,2,1.0);
    
    figure(1)
    set(gcf,'DefaultAxesFontSize',16);
    set(gcf,'DefaultTextFontSize',16);
    plot(t, Vrms);
    hold on;
    title('Daily Voltage Fluctuation');
    ylabel('Volts [pu]');
    xlabel('Time [hr]');   
    
%     figure(2);
%     plot(t, P,'-k');
%     hold on;
%     plot(t, Q,'-r');
%     legend('P','Q','Location','SouthEast');
%     title('Real and Reactive Power Fluctuation');
%     ylabel('[kW] or [kVAR]');
%     xlabel('Time [hr]');    
%     hold off

else
    a='DSS Did Not Start';
    disp(a)
end