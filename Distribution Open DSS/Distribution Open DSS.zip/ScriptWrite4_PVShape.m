% Created by Xiangqi Zhu  on Sep 7, 2016
% To add PV into the system


clear;clc; close all;
%Read in the load name information
filename='IEEE123.xlsx';
sheet='Sheet1';
range='C1:C91';
[num,txt,raw]=xlsread(filename, sheet,range,'txt');

% Read in the load bus name  
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='D1:D91';
[num1,txt1,raw1]=xlsread(filename, sheet,range,'txt');

% Read in the peak real load
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='N1:N91';
[num2,txt2,raw2]=xlsread(filename, sheet,range);

% Read in the phase 
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='F1:F91';
[num3,txt3,raw3]=xlsread(filename, sheet,range);

% Process the raw1 to make it all strings
N=numel(raw1);
for i=1:N
    tf = isnumeric(raw1{i});
    if tf==1
        raw1{i}=num2str(raw1{i});
    end
end
        
%------------------Write the loadshape information ------------------
load('YearPeak.mat') % Get the 100% penetration capacity
pene=1;
PVcapa=YearPeak*pene;
N=numel(txt); % number of load
fileID = fopen('IEEE123PVshape_allloads_5min.txt','wt');
for i=1:N
    PVshape=['New LoadShape.PVShape' txt{i} '  npts=288  minterval=[5] mult=(File=PVShape' txt{i} '.csv ) Action=Normalize'  '   \n'];
    fprintf(fileID,PVshape);
%     PVsystem=['New PVSystem.PV' txt{i} '  phases=' num2str(num3(i))  '  bus1=' raw1{i}  ' KV=2.4018' ' KVA=' num2str(PVcapa(i)) '  Pmpp=' num2str(PVcapa(i)) ' PF=1 duty=PVShape' txt{i}  '   \n'];
%     fprintf(fileID,PVsystem);
end