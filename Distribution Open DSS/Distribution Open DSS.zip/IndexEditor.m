% Created by Xiangqi Zhu 
% To edit the index
clear;clc;close all;
load('Index.mat')
Index{34}=[];
Index{35}=[];
Index{37}=[];
Index{38}=[];

Index{38}=Index{36};
Index{36}=[];


Index{34:91}=Index{38:95};