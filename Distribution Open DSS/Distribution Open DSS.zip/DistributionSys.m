% Created by Xiangqi Zhu on Nov 30, 2016
% To fulfill the demand response from subtranmission level,
% and also do the local voltage profile check and do local demand response

% Currently, no regulators are used in this circuit, and 
% Edited by Xiangqi zhu on Dec 9, 2016

function [DR_Constraint_P, DR_Constraint_Q,PV_Constraint_P,PV_Constraint_Q, Load,Load_Q,PV,V1]=DistributionSys(Load,Load_Q,PV,PVP,PV_Q,DeltP,DeltQ,TimeStep,Vsub)


%% Load PV profiles and load profiles
N=91; % Load bus number
S=max(PV,[],2)*11/9;% Capacity of PV at each bus 

%% Run original simulation
NewloadDSSCreatorPQ(Load,Load_Q);   
LoadCSVCreator(Load);
LoadCSVCreatorQ(Load_Q,TimeStep);
[V0]=RunSimu(Vsub,TimeStep);
%% Get the data at the present time step out 
PresLoad=Load(:,TimeStep);
NextLoad=Load(:,(TimeStep+1));
PresPV=PV(:,TimeStep);
PresV0=V0(:,TimeStep);

%% Select the buses on which we should do demand response
[PresV1,Node]=sortrows(PresV0); % Ascending order 


%% Disaggregate the demand response requirement to distribution feeder 
[PresLoad, NextLoad ,PresPV]=Pdisag(PresLoad, NextLoad ,PresPV ,Node,DeltP,N, PVP);
Load(:,TimeStep)=PresLoad;
% Load_Q(:,(TimeStep))=PresLoad_Q;
Load(:,(TimeStep+1))=NextLoad;
% Load_Q(:,(TimeStep+1))=NextLoad_Q;
PV(:,(TimeStep))=PresPV;
[Load_Q]=Qdisagnew(DeltQ,TimeStep,Load_Q, PV,S,N,PV_Q);



LoadCSVCreator(Load);
[Load_Q]=LoadCSVCreatorQ(Load_Q,TimeStep);

NewloadDSSCreatorPQ(Load,Load_Q); 
[V1]=RunSimu(Vsub,TimeStep);

%% Generate new constraints
DR_Constraint_P=[sum(Load(:,TimeStep+1))*0.08,-sum(Load(:,TimeStep+1))*0.08];
DR_Constraint_Q=[sum(Load_Q(:,TimeStep+1))*0.08,-sum(Load_Q(:,TimeStep+1))*0.08];
PV_Constraint_P=sum(PV(:,TimeStep+1))*0.3;




for i=1:91
    
    [dummy, PV_Q(i)]=SmartInverter((PV(i,TimeStep)),S(i));
end
PV_Constraint_Q=sum(PV_Q)*0.3;














        
        
   
            
    
    
    
    
    
        
    
    
    
    
    







            
            
            
            
            
    
                
            
                
                
                
                
            
            
        
        
        
        
        
        
        
        
        
        
        
        
    



















