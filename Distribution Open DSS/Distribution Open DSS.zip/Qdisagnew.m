function[Load_Q]=Qdisagnew(DeltQ,TimeStep,Load_Q, PV,S,N,PV_Q)
% N=91;
DeltQ=DeltQ+PV_Q;
if DeltQ>0  % reactive power generation
    % Use smart inverter to generate reactive power 
    % Randomly choose PV panel
    DRQ=0;
    RandIndex=randperm(N);
    for i=1:N  
        if DRQ<DeltQ
            [Q_PV_low(RandIndex(i)) Q_PV_up(RandIndex(i))]= SmartInverter(PV(RandIndex(i),TimeStep),S(RandIndex(i)));

            DeltDRQ=DeltQ-DRQ;
            if Q_PV_up(RandIndex(i))>=DeltDRQ
                Load_Q(RandIndex(i),TimeStep)=Load_Q(RandIndex(i),TimeStep)-DeltDRQ;
                DRQ=DRQ+DeltDRQ;
            else
                Load_Q(RandIndex(i),TimeStep)=Load_Q(RandIndex(i),TimeStep)-Q_PV_up(RandIndex(i));
                DRQ=DRQ+Q_PV_up(RandIndex(i));
            end
        else
            break;
        end
    end
            
end

%% 
if DeltQ<0  % reactive power absorption
    % Use smart inverter to absorb reactive power 
    % Choose the PV closest to substation 
    DeltQ=abs(DeltQ);
    DRQ=0;
    RandIndex=randperm(N);
    for i=1:N
        if DRQ<DeltQ
            [Q_PV_low(RandIndex(i)) Q_PV_up(RandIndex(i))]= SmartInverter(PV(RandIndex(i),TimeStep),S(RandIndex(i)));

            DeltDRQ=DeltQ-DRQ;
            if Q_PV_up(RandIndex(i))>=DeltDRQ
                a=Load_Q(RandIndex(i),TimeStep);
                Load_Q(RandIndex(i),TimeStep)=Load_Q(RandIndex(i),TimeStep)+DeltDRQ;
                DRQ=DRQ+DeltDRQ;
            else
                a=Load_Q(RandIndex(i),TimeStep);
                Load_Q(RandIndex(i),TimeStep)=Load_Q(RandIndex(i),TimeStep)+Q_PV_up(RandIndex(i));
                DRQ=DRQ+Q_PV_up(RandIndex(i));
            end
            
            if Load_Q(RandIndex(i),TimeStep)<0
                DRQ=DRQ+a;
                Load_Q(RandIndex(i),TimeStep)=0;
            end
                
        else
            break;
        end
    end          
end


