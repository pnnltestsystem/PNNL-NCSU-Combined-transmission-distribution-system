% Created by Xiangqi Zhu on 08/31/2016
% To create csv file for each load bus 

clear;clc; close all;


% Get the load profiles of each bus ready 
load('Solar_July11.mat')
PV=Solar_July11(:,4)';

% Read in the load names 
filename='IEEE123.xlsx';
sheet='Sheet1';
range='C1:C91';
[num,txt,raw]=xlsread(filename, sheet,range,'txt');

% Read in the peak real load
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='N1:N91';
[num2,txt2,raw2]=xlsread(filename, sheet,range);

N=numel(txt);

% Create the PV profiles for each csv file
PVprofiles=zeros(N,288);
PVmax=max(PV);

for i=1:N
    Peak=num2(i);
    Profile=Peak/PVmax.*PV;
    
    PVprofiles(i,:)=Profile;
end

PVmax=max(PVprofiles,[],2);
Totalmax=sum(PVmax);
%    
%Create the csv files
PVProfilesQ=ones(N,288);
for j=1:N
    Data=PVprofiles(j,:);
    DataQ=PVProfilesQ(j,:);
%     filename=['PVShape' txt{j} '.csv'];
%     csvwrite(filename, Data');
    filename1=['PVShape' txt{j} 'Q.csv'];
    csvwrite(filename1, DataQ');
end




