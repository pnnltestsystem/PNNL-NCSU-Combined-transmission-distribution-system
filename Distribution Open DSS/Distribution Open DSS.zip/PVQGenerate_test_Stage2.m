
% Created by Xiangqi Zhu on Jun 23, 2017
% To test the  PVQdisag and PVQgenerate 

clear;clc;close all

PVQ=1000;

TimeStep=120;

load('NewLoadPVData_Day1.mat')
PV=PVDay1_new; % PV real power 

PresPV=PV(:,TimeStep);
N=91;
rand('seed',1)
Node=randperm(N);


N=91; % Load bus number
S=max(PV,[],2)*11/9;% Capacity of PV at each bus 

%% Generate Q from smart inverters of PV panels
[PVQNode,PVQreal, NodeRecord, Q_PV_low, Q_PV_up ]= PVQDisag(PVQ,PresPV,Node,S,N);
PVQGenerate(PVQNode,PV,TimeStep);
% 
Vsub=1;
[V0]=RunSimu2(Vsub,TimeStep);



