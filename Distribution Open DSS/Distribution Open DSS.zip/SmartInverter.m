function [Q_PV_low, Q_PV_up]= SmartInverter(P_PV,S)
k=1.1; % k=1.1 for a normal IGBT based PV inverter
Ppv_pu=P_PV/S;% Get per unit value of PV real power output
Qpv_pu_up=sqrt((1-Ppv_pu^2)*k^2); % Get per unit value of PV reactive power output upper bound 
Qpv_pu_low=-Qpv_pu_up;% Get per unit value of PV reactive power output lower bound 
Q_PV_up=Qpv_pu_up*S; % Get the real value of PV reactive power output upper bound 
Q_PV_low=Qpv_pu_low*S;% Get the real value of PV reactive power output lower bound 