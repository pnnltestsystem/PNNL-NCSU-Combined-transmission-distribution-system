% Created by Xiangqi Zhu on 08/31/2016
% To create csv file for each load bus 

clear;clc; 


% Get the load profiles of each bus ready 
load('Profiles2.mat')

% Get the load name ready 
load('LoadName.mat')

N=numel(txt);

BusN=91;
%Create the csv files
for j=1:BusN
   
    Data=Profiles(j,:);
%     Pmax=max(Data);
%     DataNew=Peak/Pmax.*Data;
    
    filename=['Load' txt{j} '.csv'];
    csvwrite(filename, Data');
end




