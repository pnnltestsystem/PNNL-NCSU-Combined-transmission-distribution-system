
% Created by Xiangqi Zhu on Jun 26, 2017
clear;clc;close all

load('NewLoadPVData_Day1.mat')
load('NewLoadQ.mat')

load('Load_oneyear_5min.mat')

ratio=0.3489;

Load1=Load_oneyear_5min(:,1:288);
Load2=LoadDay1_new;

Subload1=sum(Load1,1);
Subload2=sum(Load2,1);

t=0:1/12:(24-1/12);
figure(1)
plot(t,Subload1.*ratio)
hold on
plot(t,Subload2)
legend('Substation load before scaling','Substation load after scaling')
ylabel('Power(kW)')
xlabel('Time(hr)')


figure(2)
plot(t,Load1(1,:)*ratio)
hold on
plot(t,Load2(1,:))
legend('Node load before scaling','Node load after scaling')
ylabel('Power(kW)')
xlabel('Time(hr)')
