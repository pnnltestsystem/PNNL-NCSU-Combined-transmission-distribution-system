% Created by Xiangqi Zhu on Jun 30, 2017
% To read the transmission data

clear;clc;close all;
filename='TransmissionData.xlsx';
sheet='voltage_distribution_1';
rangePVQ='B2:B287';
rangeVsub='E2:E287';

PVQ=xlsread(filename,sheet,rangePVQ);
Vsub=xlsread(filename,sheet,rangeVsub);

save('Transpasseddata','PVQ','Vsub');
