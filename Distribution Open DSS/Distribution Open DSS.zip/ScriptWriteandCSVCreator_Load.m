% Created by Xiangqi Zhu on Sep 29, 2016
% To write new load dss file

clear;clc; close all;
%--------------------------Get the load data ready-----------------------
load('Profiles2.mat')
N=91; % Load bus number
Load=Profiles(1:N,:);

%--------------------------Get the peak load at each bus ready-----------
PeakP=max(Load,[],2);
PeakQ=PeakP/2;

%----------------------Get the first part of load file-------------------
filename='IEEE123Load.xlsx';
range='A1:G91';
[num ,txt, raw]=xlsread(filename,range);

filename1='IEEE123.xlsx';
sheet='Sheet1';
range1='C1:C91';
[num1,txt1,raw1]=xlsread(filename1, sheet,range1);

%----------------------Write the new file--------------------------------
[a,b]=size(txt);
fileID = fopen('IEEE123Loadsnew.DSS','wt');
for i=1:N
    
    A=[txt{i,1}  '  '];
    for j=2:b
        A=[A  txt{i,j} '  ' ];
    end
    
    B=['  kW=' num2str(PeakP(i))  '  kvar='  num2str(PeakQ(i)) '  '];
    C=['  duty=' txt1{i} '\n'];
    Loadsnew=strcat(A,B,C);
    fprintf(fileID,Loadsnew);
end

fclose(fileID);


