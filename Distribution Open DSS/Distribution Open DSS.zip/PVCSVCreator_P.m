% Created by Xiangqi Zhu on 08/31/2016
% To create csv file for each load bus 

function PVCSVCreator_P(PVprofiles)



% Read in the load names 
filename='IEEE123.xlsx';
sheet='Sheet1';
range='C1:C91';
[num,txt,raw]=xlsread(filename, sheet,range,'txt');


N=numel(txt);




for j=1:N
    Data=PVprofiles(j,:);
    filename=['PVShape' txt{j} '.csv'];
    csvwrite(filename, Data');
end




