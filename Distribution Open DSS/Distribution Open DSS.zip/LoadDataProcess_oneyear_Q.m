% Created by Xiangqi Zhu on May 4, 2017
% To process the load data

% Edited by Xiangqi Zhu on Jul 10, 2017
% To process the data of one year

clear;clc; close all;
tic

% Get load profiles at initial condition
N=91; % Load bus number
T=288*364; % data points in a year

load('Load_oneyear_5min.mat')
Load=Load_oneyear_5min(:,1:T);

TotalLoad=sum(Load,1);
LoadPeakDis=max(TotalLoad);


%%  read in the transmission load data of bus 84 and process the load data of one year
load('LoadTrans_oneyear.mat')
LoadQoneyear=LoadQoneyear*1000;
LoadPeakTrans=max(LoadQoneyear);
ratio=1/3;

% rand('seed',1)
% a=-0.1;
% b=0.1;
% r = a + (b-a).*rand(288,1);
% Factor=TotalLoad./TotalLoadDay1+r';
Factor=LoadQoneyear./TotalLoad;
TotalLoad_new=TotalLoad.*Factor;

Factornew=Factor;
for i=1:90
    Factornew=[Factornew;Factor];
end

Load_Q_oneyear_new=Load.*Factornew*ratio;

TotalLoad_sum=sum(Load_Q_oneyear_new,1);

save('LoadQData_oneyear07112017','Load_Q_oneyear_new');

% save('LoadPVData_oneyear07102017','Load_oneyear_new','PVoneyear_new_Node');











