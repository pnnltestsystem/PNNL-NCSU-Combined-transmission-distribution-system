% Created by Xiangqi Zhu on May 4, 2017
% To process the load data

clear;clc; close all;
tic

% Load PV profiles and load profiles at initial condition
N=91; % Load bus number
T=288; % data points in a day 

load('PV_oneyear_5min.mat')
load('Load_oneyear_5min.mat')
LoadDay1=Load_oneyear_5min(:,1:288);
PVDay1=PV_oneyear_5min(:,1:288);

TotalLoadDay1=sum(LoadDay1,1);
TotalPVDay1=sum(PVDay1,1);


load('PV_Load_5min.mat')

A=max(sum(Load_5min,1));



% read in the transmission load data of bus 84
filename='input_update1.xlsx';
sheet='P';
range='BP2:BP289';
TotalLoad=xlsread(filename,sheet,range);
TotalLoad=TotalLoad'*1000;
B=max(TotalLoad);
ratio=A/B;

sheet1='pv';
range1='AV2:AV289';
TransPV=xlsread(filename,sheet1,range1);
TransPV=TransPV*1000*ratio;


% Process the load data of first day 

% rand('seed',1)
% a=-0.1;
% b=0.1;
% r = a + (b-a).*rand(288,1);
% Factor=TotalLoad./TotalLoadDay1+r';
Factor=TotalLoad./TotalLoadDay1;


TotalLoadDay1_new=TotalLoadDay1.*Factor;

Factornew=Factor;
for i=1:90
    Factornew=[Factornew;Factor];
end

LoadDay1_new=LoadDay1.*Factornew*ratio;

TotalLoadDay1_sum=sum(LoadDay1_new,1);

% figure(1)
% plot(TotalLoad)
% hold on
% plot(TotalLoadDay1_new);
% 
% figure(2)
% plot(TotalLoad)
% hold on
% plot(TotalLoadDay1_sum);
% 
% figure(3)
% plot(TransPV);

% Process the PV data of first day 

LoadPeak=max(LoadDay1_new,[],2);

PeakTransPV=max(TransPV);
FactorPV=LoadPeak./PeakTransPV;

PVDay1_new=TransPV';
for i=1:90
    PVDay1_new=[PVDay1_new;TransPV'];
end

FactorPV_new=FactorPV;
for i=1:287
    FactorPV_new=[FactorPV_new FactorPV];
end

PVDay1_new=PVDay1_new.*FactorPV_new;

PVDay1_newTotal=sum(PVDay1_new,1);
% save('NewLoadPVData_Day1','LoadDay1_new','PVDay1_new')

ratio1=max(TotalLoadDay1_sum)/max(PVDay1_newTotal);

PVDay1_new=PVDay1_new*ratio1;

PVDay1_newTotal1=sum(PVDay1_new,1);

% ratio2=3000./max(PVDay1_newTotal1);
% 
% PVDay1_new=PVDay1_new*ratio2;
PVDay1_newTotal1=sum(PVDay1_new,1);


% save('NewLoadPVData_Day1','LoadDay1_new','PVDay1_new')

figure(4) 
plot(TotalLoadDay1_sum)
hold on
plot(PVDay1_newTotal1)

figure (5)
plot(TotalLoadDay1_sum-PVDay1_newTotal1)








