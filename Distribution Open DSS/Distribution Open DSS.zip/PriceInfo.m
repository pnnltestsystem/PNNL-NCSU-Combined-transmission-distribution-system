%% Price of each demand response action ($/kW)
p_PVcurtl=1; % PV curtailment 
p_PVQAdj=1; % Smart inverter reactive power adjustment 
p_LoadShift=1.5; % Load shifting
p_CapaBank=2; % Capacitor Bank switch