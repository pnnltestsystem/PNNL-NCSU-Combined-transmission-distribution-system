% Created by Xiangqi Zhu on May 4, 2017
% To process the load data

clear;clc; close all;
tic

% Load PV profiles and load profiles at initial condition
N=91; % Load bus number
T=288; % data points in a day 


load('ProfilesQ.mat')

% Process the Q data
Profiles=Profiles(1:91,:);
for i=1:288
    LoadDay1(:,i)=sum(Profiles(:,((i-1)*5+1):i*5),2)./5;
end

TotalLoadDay1=sum(LoadDay1,1);

% read in the transmission load data of bus 84
filename='input_update1.xlsx';
sheet='Q';
range='BP2:BP289';
TotalLoad=xlsread(filename,sheet,range);
TotalLoad=TotalLoad'*1000;

% Process the load data of first day 
rand('seed',1)
a=-0.1;
b=0.1;
r = a + (b-a).*rand(288,1);
% Factor=TotalLoad./TotalLoadDay1+r';

Factor=TotalLoad./TotalLoadDay1;
ratio=0.3489;

Factornew=Factor;
for i=1:90
    Factornew=[Factornew;Factor];
end

LoadDay1_new=LoadDay1.*Factornew*ratio;

TotalLoadDay1_sum=sum(LoadDay1_new,1);

% figure(1)
% plot(TotalLoad)
% hold on
% plot(TotalLoadDay1_new);

figure(2)
plot(TotalLoad)
hold on
plot(TotalLoadDay1_sum);

LoadQDay1=LoadDay1_new;
 

save('NewLoadQ','LoadQDay1')







