% Created by Xiangqi Zhu  on Sep 7, 2016
% To add PV into the system

clear;clc; close all;

% Read in the peak real load
load PVprofiles
PeakPV=max(PVprofiles,[],2);

%Read in the load name information
filename='IEEE123.xlsx';
sheet='Sheet1';
range='C1:C91';
[num,txt,raw]=xlsread(filename, sheet,range,'txt');

% Read in the load bus name  
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='D1:D91';
[num1,txt1,raw1]=xlsread(filename, sheet,range,'txt');

% Read in the phase 
filename='IEEE123PV.xlsx';
sheet='Sheet1';
range='F1:F91';
[num3,txt3,raw3]=xlsread(filename, sheet,range);

% Process the load bus name to make it all strings
N=numel(raw1);
for i=1:N
    tf = isnumeric(raw1{i});
    if tf==1
        raw1{i}=num2str(raw1{i});
    end
end
        
%------------------Write the loadshape information ------------------
N=numel(txt); % number of load
fileID = fopen('IEEE123PV_allloads.txt','wt');
for i=1:N
    PVshape=['New LoadShape.PVShape' txt{i} '  npts=1440  minterval=[1] mult=(File=PVShape' txt{i} '.csv ) Action=Normalize'  '   \n'];
    fprintf(fileID,PVshape);
    PVsystem=['New PVSystem.PV' txt{i} '  phases=' num2str(num3(i))  '  bus1=' raw1{i}  ' KV=2.4018' ' KVA=' num2str(PeakPV(i)) '  Pmpp=' num2str(PeakPV(i)) ' PF=1 duty=PVShape' txt{i}  '   \n'];
    fprintf(fileID,PVsystem);
end
fclose(fileID);





