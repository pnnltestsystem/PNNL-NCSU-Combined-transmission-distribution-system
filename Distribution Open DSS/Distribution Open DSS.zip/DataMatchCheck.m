% Created by Xiangqi Zhu on Jul 13,2017
% To check if the distribution data match the tranmission data

clear;clc; close all;
load('LoadPVData_oneyear07102017.mat')
load('LoadTrans_oneyear.mat')
load LoadQData_oneyear07112017

LoadDay1Dis=Load_oneyear_new(:,1:288);
LoadDay1Trans=LoadPoneyear(1:288)./3*1000;

Delta=sum(LoadDay1Dis,1)-LoadDay1Trans;
plot(Delta)

LoadDay1DisQ=Load_Q_oneyear_new(:,1:288);
LoadDay1TransQ=LoadQoneyear(1:288)./3*1000;
DeltaQ=sum(LoadDay1DisQ,1)-LoadDay1TransQ;
figure(2)
plot(DeltaQ)

load('PVTrans_oneyear.mat')
PVDay1Dis=PVoneyear_new_Node(:,1:288);
PVDay1Trans=PVoneyear(1:288);
DeltaPV=sum(PVDay1Dis,1)-PVDay1Trans*1000/3;
figure(3)
plot(DeltaPV)