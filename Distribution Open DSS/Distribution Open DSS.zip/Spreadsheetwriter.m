% Created by Xiangqi Zhu on Apr 18,2017 
% To initially write the coordination spreadsheet


clear;clc;
filename='CoordinationSpreadsheet.xlsx';
sheet1='DRRequirement';
Range1='D2:D289';
Range2='E2:E289';

load('PV_oneyear_5min.mat')

PV_Day1=0.2*sum(PV_oneyear_5min(:,1:288),1);

load('YearPeak.mat')
S=sum(YearPeak);

for i=1:288
    
    [dumy,PV_Day1Q(i)]= SmartInverter(PV_Day1(i)/0.2,S);
end
PV_Day1Q=PV_Day1Q*0.2;

xlswrite(filename,PV_Day1',sheet1,Range1);
xlswrite(filename, PV_Day1Q',sheet1,Range2);    
