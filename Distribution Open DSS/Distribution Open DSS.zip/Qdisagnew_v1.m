function[Load_Q,]=Qdisagnew_v1(DeltQ,TimeStep,Load_Q,N,Node)
% N=91;
ratio=0.05;
if DeltQ>0  % reactive load increase, getting more Q from grid 
    DRQreal=0;
    DRQNode=zeros(N,1);
    NodeRecord=zeros(N,1);
    for i=N:-1:1 % Choose the node with highest voltage
        NodeRecord(i)=Node(i);
        DRQNode(Node(i))=Load_Q(Node(i),TimeStep)*ratio;
        Load_Q(Node(i),TimeStep)=Load_Q(Node(i),TimeStep)*(1+ratio);
        DRQreal=DRQreal+DRQNode(Node(i));
        Delta=DeltQ-DRQreal;
        if Delta==0
            break;
        elseif Delta<0
            DRQNode(Node(i))=DRQNode(Node(i))+Delta; % Delta is negative, PVQNode is positive
            DRQreal=DRQreal+Delta;
            break;
        end
        
    end
            
end

%% 
if DeltQ<0  % reactive load decrease, getting less Q from grid 
    DRQreal=0;
    DRQNode=zeros(N,1);
    NodeRecord=zeros(N,1);
    for i=1:N % Choose the node with lowest voltage
        NodeRecord(i)=Node(i);
        DRQNode(Node(i))=Load_Q(Node(i),TimeStep)*ratio;
        Load_Q(Node(i),TimeStep)=Load_Q(Node(i),TimeStep)*(1-ratio);
        DRQreal=DRQreal+DRQNode(Node(i));
        Delta=abs(DeltQ)-DRQreal;
        if Delta==0
            break;
        elseif Delta<0
            DRQNode(Node(i))=DRQNode(Node(i))+Delta; % Delta is negative, PVQNode is positive
            DRQreal=DRQreal+Delta;
            break;
        end
        
    end
    
    DRQreal=-DRQreal;    
end



