% Created by Xiangqi Zhu on Jun 15, 2017
% To plot the result for quaterly report of 2017 Q1

clear;clc; close all;
load('NewLoadPVData_Day1.mat')

LoadSub=sum(LoadDay1_new,1);

t=0:5/60:(24-5/60);
figure(1)
set(gcf,'DefaultAxesFontSize',16);
set(gcf,'DefaultTextFontSize',16);
plot(t,LoadDay1_new(1,:));
hold on
plot(t,LoadDay1_new(3,:));
plot(t,LoadDay1_new(10,:));
xlabel('Time(hr)')
ylabel('Power(kW)')
legend('Load at Bus1PhA','Load at Bus2PhB','Load at Bus12PhB')

figure(2)
set(gcf,'DefaultAxesFontSize',16);
set(gcf,'DefaultTextFontSize',16);
plot(t,LoadSub)
xlabel('Time(hr)')
ylabel('Power(kW)')

legend('TotalLoad at Substaion')







