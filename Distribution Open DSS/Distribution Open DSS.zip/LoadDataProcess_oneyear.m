% Created by Xiangqi Zhu on May 4, 2017
% To process the load data

% Edited by Xiangqi Zhu on Jul 10, 2017
% To process the data of one year

clear;clc; close all;
tic

% Get load profiles at initial condition
N=91; % Load bus number
T=288*364; % data points in a year

load('Load_oneyear_5min.mat')
Load=Load_oneyear_5min(:,1:T);

TotalLoad=sum(Load,1);
LoadPeakDis=max(TotalLoad);


%%  read in the transmission load data of bus 84 and process the load data of one year
load('LoadTrans_oneyear.mat')
LoadPoneyear=LoadPoneyear*1000;
LoadPeakTrans=max(LoadPoneyear);
ratio=1/3;

% rand('seed',1)
% a=-0.1;
% b=0.1;
% r = a + (b-a).*rand(288,1);
% Factor=TotalLoad./TotalLoadDay1+r';
Factor=LoadPoneyear./TotalLoad;
TotalLoad_new=TotalLoad.*Factor;

Factornew=Factor;
for i=1:90
    Factornew=[Factornew;Factor];
end

Load_oneyear_new=Load.*Factornew*ratio;

TotalLoad_sum=sum(Load_oneyear_new,1);


% figure(1)
% plot(TotalLoad)
% hold on
% plot(TotalLoadDay1_new);
% 
% figure(2)
% plot(TotalLoad)
% hold on
% plot(TotalLoadDay1_sum);
% 
% figure(3)
% plot(TransPV);

 
%%  process the PV data 
load('PVTrans_oneyear.mat')
PVoneyear=PVoneyear*1000*ratio;
PeakTransPV=max(PVoneyear);
PeakTransPV_new=PeakTransPV;
LoadPeak=max(Load_oneyear_new,[],2);
TotalLoadPeak=sum(LoadPeak);
NodePVratio=LoadPeak./TotalLoadPeak;


PVoneyear_new=PVoneyear;
for i=1:90
    PVoneyear_new=[PVoneyear_new;PVoneyear];
end

for i=1:91
    PVoneyear_new_Node(i,:)=PVoneyear_new(i,:)*NodePVratio(i);
end



save('LoadPVData_oneyear07102017','Load_oneyear_new','PVoneyear_new_Node');


% figure(4) 
% plot(TotalLoadDay1_sum)
% hold on
% plot(PVDay1_newTotal1)
% 
% figure (5)
% plot(TotalLoadDay1_sum-PVDay1_newTotal1)








