% Created by Xiangqi Zhu on Sep 29, 2016
% To write new load dss file

function NewloadDSSCreatorPQ(LoadP,LoadQ)

%--------------------------Get the peak load at each bus ready-----------
PeakP=max(LoadP,[],2);
PeakQ=max(LoadQ,[],2);
N=91;

%----------------------Get the first part of load file-------------------
filename='IEEE123Load.xlsx';
range='A1:G91';
[num ,txt, raw]=xlsread(filename,range);

%-----------------Get the third part of load file-----------------------
filename1='IEEE123.xlsx';
sheet='Sheet1';
range1='C1:C91';
[num1,txt1,raw1]=xlsread(filename1, sheet,range1);

%----------------------Write the new file--------------------------------
[a,b]=size(txt);
fileID = fopen('IEEE123Loadsnew.DSS','wt');
for i=1:N
    
    A=[txt{i,1}  '  '];
    for j=2:b
        A=[A  txt{i,j} '  ' ];
    end
    
    B=['  kW=' num2str(PeakP(i))  '  kvar='  num2str(PeakQ(i)) '  '];
    C=['  duty=' txt1{i} '\n'];
    Loadsnew=strcat(A,B,C);
    fprintf(fileID,Loadsnew);
end

fclose(fileID);


