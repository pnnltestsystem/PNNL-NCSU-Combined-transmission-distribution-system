 

clear;clc;

load('PV_oneyear.mat')

for i=1:366
    PV_oneyearDaily(i,:)=PV_oneyear(((i-1)*288+1):i*288);
end

save('PV_oneyearDaily','PV_oneyearDaily')


PV_peak_year=max(PV_oneyear);

load('YearPeak.mat')

N=numel(YearPeak);

for i=1:N
    Ratio=YearPeak(i)/PV_peak_year;
    PV_oneyear_5min(i,:)=Ratio*PV_oneyear;
end

save('PV_oneyear_5min','PV_oneyear_5min')

    

