% Create by Xiangqi Zhu on 8/29/2016
% To write script loadshape.dss (txt)

clear;clc;

%-------------------Read in the load bus information--------------------

filename='IEEE123.xlsx';
sheet='Sheet1';
range='C1:C91';
[num,txt,raw]=xlsread(filename, sheet,range,'txt');

%------------------Write the loadshape information ------------------
N=numel(txt); % number of load
fileID = fopen('IEEE123loadshape_new.dss','wt');
for i=1:N
    Loadshape=['New LoadShape.' txt{i} ' npts=288  minterval=[5] Pmult=(File=Load' txt{i} '.csv )  qmult=(File=Load' txt{i} 'Q.csv )   Action=Normalize \n'];
    fprintf(fileID,Loadshape);
end
fclose(fileID);
