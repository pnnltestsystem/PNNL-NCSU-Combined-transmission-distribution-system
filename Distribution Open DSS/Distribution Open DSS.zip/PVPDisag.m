% Created by Xiangqi Zhu on Jun 26, 2017
% To implement PV curtailment 

function [PVPNode,PVPreal, NodeRecord,PresPV]= PVPDisag(PVP,PresPV,Node,N)

ratio=0.8;
% The ratio to the P curtailment capacity that each PV panel could provide maximumly at
% a time step
  
%% Implement the PVQ requirment  
PVPreal=0;
PVPNode=zeros(N,1);
NodeRecord=zeros(N,1);
for i=1:N % Choose the node with lowest voltage
    NodeRecord(i)=Node(i);
    PVPNode(Node(i))=PresPV(Node(i))*ratio;
    PresPV(Node(i))=PresPV(Node(i))*(1-ratio);
    PVPreal=PVPreal+PVPNode(Node(i));
    Delta=PVP-PVPreal;
    if Delta==0
        break;
    elseif Delta<0
        PVPNode(Node(i))=PVPNode(Node(i))+Delta; % Delta is negative, PVQNode is positive
        PVPreal=PVPreal+Delta;
        PresPV(Node(i))=PresPV(Node(i))-Delta;
        break;
    end
    
end





