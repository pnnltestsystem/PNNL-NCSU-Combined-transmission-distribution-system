% Created by Xiangqi Zhu on Jun 22, 2017
% To disaggregate the total PVQ to each PV panel

function [PVQNode,PVQreal, NodeRecord, Q_PV_low, Q_PV_up]= PVQDisag(PVQ,PresPV,Node,S,N)
% PVQ is the Q generation requirement from subtransmision system,
% PresPV is the PV real power output of each node at this timestep,
% Node is the node numbers ranked by voltage
% S is the capacity of 

% The node voltage was ranked in an ascending order, therefore, the first
% node has lowest voltage
PVQNode=zeros(N,1);
ratio=0.9;
% The ratio to the Q capacity that each PV panel could provide maximumly at
% a time step

%% Get the Q availablity of PV panel at each node
for i=1:N
    [Q_PV_low(i), Q_PV_up(i)]= SmartInverter(PresPV(i),S(i));
end
    

%% Implement the PVQ requirment  
if PVQ>=0 % Generate reactive power 
    PVQreal=0;
    PVQNode=zeros(N,1);
    NodeRecord=zeros(N,1);
    for i=1:N % Choose the node with lowest voltage
        NodeRecord(i)=Node(i);
        PVQNode(Node(i))=Q_PV_up(Node(i))*ratio;
        PVQreal=PVQreal+PVQNode(Node(i));
        Delta=PVQ-PVQreal;
        if Delta==0
            break;
        elseif Delta<0
            PVQNode(Node(i))=PVQNode(Node(i))+Delta; % Delta is negative, PVQNode is positive
            PVQreal=PVQreal+Delta;
            break;
        end
        
    end
end


if PVQ<0 % absorb reactive power 
    PVQreal=0;
    PVQNode=zeros(N,1);
    NodeRecord=zeros(N,1);
    for i=N:-1:1 % Choose the node with lowest voltage
        NodeRecord(N+1-i)=Node(i);
        PVQNode(Node(i))=Q_PV_low(Node(i))*ratio;
        PVQreal=PVQreal+PVQNode(Node(i));
        Delta=abs(PVQ)-abs(PVQreal);
        if Delta==0
            break;
        elseif Delta<0
            PVQNode(Node(i))=PVQNode(Node(i))-Delta; % Delta is negative, PVQNode is also negative
            PVQreal=PVQreal-Delta;
            break;
        end
        
    end
end



    
    
